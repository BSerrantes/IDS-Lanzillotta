from flask import Flask, render_template, url_for, request, redirect

app = Flask(__name__)

@app.route("/")
def Home():
    Nombre = "Bryan"
    Apellido = "Serrantes" 
    return render_template("home.html", nombre=Nombre, apellido=Apellido)

@app.route("/datos_personales",methods=["GET","POST"])
def Formulario():
    if request.method == "POST":
        
        return render_template("aceptado.html", nombre, apellido, celular, direccion, dni)

    return render_template("formulario.html")

@app.route("/aceptado")
def Aceptado():
    return render_template("aceptado.html")

if __name__ == "__main__":
    app.run("127.0.0.1",port="8080", debug=True)
